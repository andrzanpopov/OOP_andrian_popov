class Pilt:
    def __init__(self, nimi):
        self.nimi = nimi
    
    def valjasta_nimi(self):
        print("Pildi nimi on:", self.nimi)


class VektorPilt(Pilt):
    def __init__(self, nimi, formaat):
        super().__init__(nimi)
        self.formaat = formaat 

    def valjasta_formaat(self):
        print("VektorPildi formaat on:", self.formaat)


class RasterPilt(Pilt):
    def __init__(self, nimi, formaat, pikslid):
        super().__init__(nimi)
        self.formaat = formaat  
        self.pikslid = pikslid  

    def valjasta_andmed(self):
        print("RasterPildi formaat on:", self.formaat)
        print("Pikslite arv on:", self.pikslid)



pilt1 = Pilt("Minu pilt")
pilt1.valjasta_nimi()

print()  

vektor1 = VektorPilt("Logo", "SVG")
vektor1.valjasta_nimi()       
vektor1.valjasta_formaat()    

print()

raster1 = RasterPilt("Foto", "PNG", 2048)
raster1.valjasta_nimi()       
raster1.valjasta_andmed()     
