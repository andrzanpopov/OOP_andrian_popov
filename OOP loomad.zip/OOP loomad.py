class Loom:
    def __init__(self, nimi):
        self.nimi = nimi  
    
    def haalitsus(self):
        print("Häälitsus")

class Koer(Loom):
    def haalitsus(self):
        print("Auh")

class Kass(Loom):
    def haalitsus(self):
        print("Miäu")

class Lehm(Loom):
    def haalitsus(self):
        print("Muuuuuuu")

class Kukk(Loom):
    def haalitsus(self):
        print("kikkerikiiii")


koer = Koer("Rex")
koer.haalitsus()  

kass = Kass("Pussi")
kass.haalitsus()  

lehm = Lehm("Paksu")
lehm.haalitsus()

kukk = Kukk("Kukk")
kukk.haalitsus()  