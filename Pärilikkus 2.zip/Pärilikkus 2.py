class Loomad:
    def __init__(self, kasOnJalad, korgus, toitumine, vanus):
        self.kasOnJalad = kasOnJalad 
        self.korgus = korgus  
        self.toitumine = toitumine  
        self.vanus = vanus  

    def kasva(self, kasv):
        self.korgus += kasv

    def vanane(self, aastat):
        self.vanus += aastat


class Imetajad(Loomad):
    def __init__(self, kasOnJalad, korgus, toitumine, vanus, sugu):
        super().__init__(kasOnJalad, korgus, toitumine, vanus)
        self.sugu = sugu 

    def sure(self):
        if self.vanus > 211:
            print("Vanemaid imetajaid ei ole olnud.")


class Inimesed(Imetajad):
    def __init__(self, kasOnJalad, korgus, toitumine, vanus, sugu, nimi, kodakondsus):
        super().__init__(kasOnJalad, korgus, toitumine, vanus, sugu)
        self.nimi = nimi  
        self.kodakondsus = kodakondsus

    def sure(self):
        if self.vanus > 121:
            print(f"{self.nimi} on surnud, kuna ta on vanem kui 121 aastat.")

    def valjastaAndmed(self):
        print(f"Tere {self.nimi}, sa oled pärit {self.kodakondsus}. Sa oled {self.vanus} aastat vana ning oled {self.korgus} cm kõrge.")
        print(f"Sa oled {self.sugu} soost ja sa oled {self.toitumine} toitlane.")



loom1 = Loomad(True, 150, "Segu", 5)
loom1.kasva(10) 
loom1.vanane(2) 
print(f"Loom on {loom1.korgus} cm kõrge ja {loom1.vanus} aastat vana.")

print("\n")

imetaja1 = Imetajad(True, 100, "Liha", 250, "M")
imetaja1.sure()  

print("\n")

inimene1 = Inimesed(True, 180, "Segu", 30, "M", "John", "USA")
inimene1.valjastaAndmed()  

inimene1.sure() 

print("\n")

inimene2 = Inimesed(True, 160, "Taime", 130, "N", "Anna", "Eesti")
inimene2.sure()
