class Treening:
    def __init__(self, ala, kestus):
        self.ala = ala
        self.kestus = kestus
        self.kulu = 0  
    
    def arvutaKulu(self):
        """Arvutab kalorikulu vastavalt treeningu alale ja kestusele."""
        if self.ala == "Jooks":
            self.kulu = self.kestus * 10
        elif self.ala == "Ujumine":
            self.kulu = self.kestus * 13
        elif self.ala == "Raskus":
            self.kulu = self.kestus * 8
        else:
            self.kulu = self.kestus * 5  
        return self.kulu


class Sportlane(Treening):
    def __init__(self, ala, kestus, nimi):
        super().__init__(ala, kestus)
        self.nimi = nimi
        self.energia = 50  
        self.kestus = kestus  
        
    def treeni(self):
        """Teostab treeningu, kui energiat on piisavalt."""
        if self.energia < 20:
            print(f"{self.nimi}, pole piisavalt energiat treenimiseks!")
            return
        else:
            print(f"{self.nimi}, treening tehtud!")
            self.arvutaKulu()  
            self.energia -= (self.kestus // 10)
            if self.energia < 0:
                self.energia = 0  
            print(f"Treeningu kestus: {self.kestus} minutit, kalorikulu: {self.kulu} kcal, energia: {self.energia}")
    
    def puhka(self, minutid):
        """Puhkab ja taastab energiat."""
        self.energia += (minutid // 5)
        if self.energia > 100:
            self.energia = 100  
        print(f"Peale puhkust, energia: {self.energia}")

sportlane = Sportlane("Jooks", 30, "Mati")

print(f"Algandmed: {sportlane.nimi} teeb treeningut {sportlane.ala} {sportlane.kestus} minutiks.")
print(f"Algenergia: {sportlane.energia}")

sportlane.treeni()

sportlane.puhka(20)

while True:
    if sportlane.energia < 20:  
        print("Energia otsas, rohkem treenida ei saa.")
        break
    sportlane.treeni()

print(f"Lõppandmed: {sportlane.ala}, kestus: {sportlane.kestus} min, kalorikulu: {sportlane.kulu}, energia: {sportlane.energia}")