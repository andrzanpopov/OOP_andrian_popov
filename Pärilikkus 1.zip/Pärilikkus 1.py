class Soiduk:
    def __init__(self, maxKiirus, nimi, istekohtadeArv):
        self.maxKiirus = maxKiirus  
        self.nimi = nimi  
        self.istekohtadeArv = istekohtadeArv 

    def info(self):
        print(f"Sõiduki nimi: {self.nimi}")
        print(f"Maksimaalne kiirus: {self.maxKiirus} km/h")
        print(f"Istekohtade arv: {self.istekohtadeArv}")

class Buss(Soiduk):
    def __init__(self, maxKiirus, nimi, istekohtadeArv, piletiHind):
        super().__init__(maxKiirus, nimi, istekohtadeArv)
        self.piletiHind = piletiHind  
        self.soitjateArv = 0  

    def ostaPilet(self, arv):
        self.soitjateArv += arv
        print(f"Osteti {arv} piletit. Sõitjate arv on nüüd {self.soitjateArv}.")

    def info(self):
        super().info()  
        print(f"Bussipileti hind: {self.piletiHind} eurot")
        print(f"Sõitjate arv: {self.soitjateArv}")


soiduk1 = Soiduk(180, "Audi A4", 5)
soiduk1.info()  

print("\n") 

buss1 = Buss(100, "LUXExpress", 50, 2.5)
buss1.info()  

buss1.ostaPilet(5)  
buss1.ostaPilet(3)  
