class Kujund:
    def pindala(self):
        return 0 


class Ruut(Kujund):
    def __init__(self, kulg):
        self.kulg = kulg

    def pindala(self):
        return self.kulg * self.kulg 


class Ring(Kujund):
    def __init__(self, raadius):
        self.raadius = raadius

    def pindala(self):
        return 3.14 * (self.raadius ** 2) 


ruut1 = Ruut(4)
ruut2 = Ruut(10)

ring1 = Ring(3)
ring2 = Ring(7)

print("Ruut 1 pindala:", ruut1.pindala())
print("Ruut 2 pindala:", ruut2.pindala())

print("Ring 1 pindala:", ring1.pindala())
print("Ring 2 pindala:", ring2.pindala())