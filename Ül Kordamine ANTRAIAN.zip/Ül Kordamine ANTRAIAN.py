class Raamat:
    def __init__(self, pealkiri, autor, zanr, saadavus):
        self.pealkiri = pealkiri 
        self.autor = autor  
        self.zanr = zanr  
        self.saadavus = saadavus 

    def valjasta_andmed(self):
        print(f"Raamat nimega '{self.pealkiri}' kirjutas autor {self.autor}.")
        print(f"Raamatu žanr on {self.zanr} ning raamat on hetkel {'saadaval' if self.saadavus else 'välja laenutatud'}.")


class Raamatukogu:
    def __init__(self):
        self.raamatud = []

    def lisa_raamat(self, raamat):
        self.raamatud.append(raamat)

    def laenuta_raamat(self, pealkiri):
        for raamat in self.raamatud:
            if raamat.pealkiri == pealkiri:
                if raamat.saadavus: 
                    raamat.saadavus = False 
                    print(f"Raamat '{pealkiri}' on nüüd välja laenutatud.")
                    return
                else:
                    print(f"Raamat '{pealkiri}' on juba välja laenutatud ja ei ole saadaval.")
                    return
        print(f"Raamatut '{pealkiri}' ei leitud raamatukogust.")  # Kui raamatut ei leita

    def tagasta_raamat(self, pealkiri):
        for raamat in self.raamatud:
            if raamat.pealkiri == pealkiri:
                if not raamat.saadavus:  
                    raamat.saadavus = True  
                    print(f"Raamat '{pealkiri}' on tagastatud ja nüüd saadaval.")
                    return
                else:
                    print(f"Raamat '{pealkiri}' on juba saadaval.")
                    return
        print(f"Raamatut '{pealkiri}' ei leitud raamatukogust.")  # Kui raamatut ei leita



raamat1 = Raamat("Tarkus ja rahu", "Leo Tolstoi", "Filosofia", True)
raamat2 = Raamat("Võim ja kiusatus", "George Orwell", "Düstoopia", True)
raamat3 = Raamat("Vana mees ja meri", "Ernest Hemingway", "Draama", True)

raamatukogu = Raamatukogu()

raamatukogu.lisa_raamat(raamat1)
raamatukogu.lisa_raamat(raamat2)
raamatukogu.lisa_raamat(raamat3)

raamat1.valjasta_andmed()
raamat2.valjasta_andmed()
raamat3.valjasta_andmed()

print("\n")

raamatukogu.laenuta_raamat("Tarkus ja rahu")
raamatukogu.laenuta_raamat("Tarkus ja rahu") 

print("\n")

raamatukogu.tagasta_raamat("Tarkus ja rahu")
raamatukogu.tagasta_raamat("Tarkus ja rahu")  

print("\n")

raamat1.valjasta_andmed()
raamat2.valjasta_andmed()
raamat3.valjasta_andmed()
